A keyboard plugin that allows input of accented characters. European keyboard layouts (Russian, French, Spanish, etc.) will be added later. 

***Plugin Installation***
1. Compress the files in the plugin folder (exclude the folder itself).
2. Copy the zip file to the Android SD card at /DictTango/Plugins/InputPlugins.

