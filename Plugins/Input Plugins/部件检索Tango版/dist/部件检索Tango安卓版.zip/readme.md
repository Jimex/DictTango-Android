安装方法:
1) 把"部件检索Tango安卓版.zip"复制到SDCard上/DictTango/Plugins/InputPlugins
2）把"全宋体手机版.zip"中的文件解压到SDCard上/DictTango/UserAssets/Fonts